import java.io.Serializable;

public class DZ implements Serializable {
    private transient int id;
    private  String hw;
    DZ(String hw){
        this.hw = hw;
    }
}
