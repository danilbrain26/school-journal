import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws FileNotFoundException {
        String dz;
        String MONDAYDZ = null;
        String TUESDAYDZ = null;
        String WEDNESDAYDZ = null;
        String THURSDAYDZ = null;
        String FRIDAYDZ = null;
        Scanner sc = new Scanner(System.in);
        System.out.println("Вы учитель или ученик?");
        String pr = sc.nextLine();
        if (pr.equals("Учитель") || pr.equals("учитель")) {
            String b;
            System.out.println("Вы зарегистрированы?");
            System.out.println("Да или нет");
            int sum = 0;
            do {
                if (sum > 0) {
                    System.out.println("Вы зарегистрированы?");
                    System.out.println("Да или нет");
                }
                b = sc.nextLine();
                sum++;
            } while (!b.equals("Да") && !b.equals("да") && !b.equals("Нет") && !b.equals("нет"));
            System.out.println("Введите имя пользователя:");
            if (b.equals("Да") || b.equals("да")) {
                String q;
                sum = 0;
                do {
                    if (sum > 0) {
                        System.out.println("Введите имя пользователя:");
                    }
                    q = sc.nextLine();
                    sum++;
                } while (q.isEmpty());
                System.out.println("Введите пароль:");
                String w;
                sum = 0;
                do {
                    if (sum > 0) {
                        System.out.println("Введите пароль:");
                    }
                    w = sc.nextLine();
                    sum++;
                } while (w.isEmpty());
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Registration"))) {
                    Person person2 = new Person(q, w);
                    Person person = (Person) ois.readObject();
                    if (person.equals(person2)) {
                        System.out.println("Поздравляем, вы вошли в систему");
                        System.out.println("На какой день недели задать дз ученикам?");
                        System.out.println("1 - Понедельник");
                        System.out.println("2 - Вторник");
                        System.out.println("3 - Среда");
                        System.out.println("4 - Четверг");
                        System.out.println("5 - Пятница");
                        int a = sc.nextInt();
                        sum = 0;
                        do {
                            if (sum > 0) {
                                System.out.println("Введите правильное число:");
                                a = sc.nextInt();
                            }
                            switch (a) {
                                case 1 -> {
                                    char zap = ',';
                                    DayOfWeeks monday = DayOfWeeks.Monday;
                                    String c = monday.getSubjects();
                                    ArrayList<String> arr = new ArrayList<String>();
                                    String st = "";
                                    System.out.println("Предметы учеников на понедельник:");
                                    for (int i = 0; i < c.length(); i++) {
                                        if (Character.compare(c.charAt(i), zap) == 0) {
                                            System.out.println();
                                            arr.add(st);
                                            st = "";
                                        } else {
                                            st += c.charAt(i);
                                            System.out.print(c.charAt(i));
                                        }
                                    }
                                    arr.add(st);
                                    System.out.println();
                                    do {
                                        dz = sc.nextLine();
                                        if (dz.equals("да") || dz.equals("Да")){
                                            for(int i = 0; i < arr.size(); i++){
                                                System.out.println(i + 1 + " предмет - " + arr.get(i));
                                                System.out.println("Напишите дз:");
                                                String x = sc.nextLine();
                                                MONDAYDZ += arr.get(i) + " - " + x + ",";
                                            }
                                            break;
                                        }
                                        else if(dz.equals("нет") || dz.equals("Нет")){
                                            break;
                                        }
                                        System.out.println("Задать ученикам дз на понедельник? Да или нет");
                                    } while(dz.isEmpty());
                                    System.out.println("Дз на понедельник записано");
                                    String CorrectDZ = "";
                                    CorrectDZ = MONDAYDZ.substring(4);
                                    System.out.println(CorrectDZ);
                                    Path path = Paths.get("HWMonday");
                                    try{
                                        Files.writeString(path, CorrectDZ, StandardCharsets.UTF_8);
                                    } catch (IOException ex){
                                        System.out.println("Invalid Path");
                                    }
                                }
                                case 2 -> {
                                    char zap1 = ',';
                                    DayOfWeeks tuesday = DayOfWeeks.Tuesday;
                                    String c1 = tuesday.getSubjects();
                                    ArrayList<String> arr1 = new ArrayList<String>();
                                    String st1 = "";
                                    System.out.println("Предметы учеников на вторник:");
                                    for (int i = 0; i < c1.length(); i++) {
                                        if (Character.compare(c1.charAt(i), zap1) == 0) {
                                            System.out.println();
                                            arr1.add(st1);
                                            st1 = "";
                                        } else {
                                            st1 += c1.charAt(i);
                                            System.out.print(c1.charAt(i));
                                        }
                                    }
                                    arr1.add(st1);
                                    System.out.println();
                                    do {
                                        dz = sc.nextLine();
                                        if (dz.equals("да") || dz.equals("Да")){
                                            for(int i = 0; i < arr1.size(); i++){
                                                System.out.println(i + 1 + " предмет - " + arr1.get(i));
                                                System.out.println("Напишите дз:");
                                                String x1 = sc.nextLine();
                                                TUESDAYDZ += arr1.get(i) + " - " + x1 + ",";
                                            }
                                            break;
                                        }
                                        else if(dz.equals("нет") || dz.equals("Нет")){
                                            break;
                                        }
                                        System.out.println("Задать ученикам дз на вторник? Да или нет");
                                    } while(dz.isEmpty());
                                    System.out.println("Дз на вторник записано");
                                    String CorrectDZ1 = "";
                                    CorrectDZ1 = TUESDAYDZ.substring(4);
                                    System.out.println(CorrectDZ1);
                                    Path path1 = Paths.get("HWTuesday");
                                    try{
                                        Files.writeString(path1, CorrectDZ1, StandardCharsets.UTF_8);
                                    } catch (IOException ex){
                                        System.out.println("Invalid Path");
                                    }
                                }
                                case 3 -> {
                                    char zap2 = ',';
                                    DayOfWeeks wednesday = DayOfWeeks.Wednesday;
                                    String c2 = wednesday.getSubjects();
                                    ArrayList<String> arr2 = new ArrayList<String>();
                                    String st2 = "";
                                    System.out.println("Предметы учеников на среду:");
                                    for (int i = 0; i < c2.length(); i++) {
                                        if (Character.compare(c2.charAt(i), zap2) == 0) {
                                            System.out.println();
                                            arr2.add(st2);
                                            st2 = "";
                                        } else {
                                            st2 += c2.charAt(i);
                                            System.out.print(c2.charAt(i));
                                        }
                                    }
                                    arr2.add(st2);
                                    System.out.println();
                                    do {
                                        dz = sc.nextLine();
                                        if (dz.equals("да") || dz.equals("Да")){
                                            for(int i = 0; i < arr2.size(); i++){
                                                System.out.println(i + 1 + " предмет - " + arr2.get(i));
                                                System.out.println("Напишите дз:");
                                                String x2 = sc.nextLine();
                                                WEDNESDAYDZ += arr2.get(i) + " - " + x2 + ",";
                                            }
                                            break;
                                        }
                                        else if(dz.equals("нет") || dz.equals("Нет")){
                                            break;
                                        }
                                        System.out.println("Задать ученикам дз на среду? Да или нет");
                                    } while(dz.isEmpty());
                                    System.out.println("Дз на среду записано");
                                    String CorrectDZ2 = "";
                                    CorrectDZ2 = WEDNESDAYDZ.substring(4);
                                    System.out.println(CorrectDZ2);
                                    Path path2 = Paths.get("HWWednesday");
                                    try{
                                        Files.writeString(path2, CorrectDZ2, StandardCharsets.UTF_8);
                                    } catch (IOException ex){
                                        System.out.println("Invalid Path");
                                    }
                                }
                                case 4 -> {
                                    char zap3 = ',';
                                    DayOfWeeks friday = DayOfWeeks.Thursday;
                                    String c3 = friday.getSubjects();
                                    ArrayList<String> arr3 = new ArrayList<String>();
                                    String st3 = "";
                                    System.out.println("Предметы учеников на четверг:");
                                    for (int i = 0; i < c3.length(); i++) {
                                        if (Character.compare(c3.charAt(i), zap3) == 0) {
                                            System.out.println();
                                            arr3.add(st3);
                                            st3 = "";
                                        } else {
                                            st3 += c3.charAt(i);
                                            System.out.print(c3.charAt(i));
                                        }
                                    }
                                    arr3.add(st3);
                                    System.out.println();
                                    do {
                                        dz = sc.nextLine();
                                        if (dz.equals("да") || dz.equals("Да")){
                                            for(int i = 0; i < arr3.size(); i++){
                                                System.out.println(i + 1 + " предмет - " + arr3.get(i));
                                                System.out.println("Напишите дз:");
                                                String x3 = sc.nextLine();
                                                THURSDAYDZ += arr3.get(i) + " - " + x3 + ",";
                                            }
                                            break;
                                        }
                                        else if(dz.equals("нет") || dz.equals("Нет")){
                                            break;
                                        }
                                        System.out.println("Задать ученикам дз на четверг? Да или нет");
                                    } while(dz.isEmpty());
                                    System.out.println("Дз на четверг записано");
                                    String CorrectDZ3 = "";
                                    CorrectDZ3 = THURSDAYDZ.substring(4);
                                    System.out.println(CorrectDZ3);
                                    Path path3 = Paths.get("HWThursday");
                                    try{
                                        Files.writeString(path3, CorrectDZ3, StandardCharsets.UTF_8);
                                    } catch (IOException ex){
                                        System.out.println("Invalid Path");
                                    }
                                }
                                case 5 -> {
                                    char zap4 = ',';
                                    DayOfWeeks friday = DayOfWeeks.Friday;
                                    String c4 = friday.getSubjects();
                                    ArrayList<String> arr4 = new ArrayList<String>();
                                    String st4 = "";
                                    System.out.println("Предметы учеников на пятницу:");
                                    for (int i = 0; i < c4.length(); i++) {
                                        if (Character.compare(c4.charAt(i), zap4) == 0) {
                                            System.out.println();
                                            arr4.add(st4);
                                            st4 = "";
                                        } else {
                                            st4 += c4.charAt(i);
                                            System.out.print(c4.charAt(i));
                                        }
                                    }
                                    arr4.add(st4);
                                    System.out.println();
                                    do {
                                        dz = sc.nextLine();
                                        if (dz.equals("да") || dz.equals("Да")){
                                            for(int i = 0; i < arr4.size(); i++){
                                                System.out.println(i + 1 + " предмет - " + arr4.get(i));
                                                System.out.println("Напишите дз:");
                                                String x4 = sc.nextLine();
                                                FRIDAYDZ += arr4.get(i) + " - " + x4 + ",";
                                            }
                                            break;
                                        }
                                        else if(dz.equals("нет") || dz.equals("Нет")){
                                            break;
                                        }
                                        System.out.println("Задать ученикам дз на пятницу? Да или нет");
                                    } while(dz.isEmpty());
                                    System.out.println("Дз на пятницу записано");
                                    String CorrectDZ4 = "";
                                    CorrectDZ4 = FRIDAYDZ.substring(4);
                                    System.out.println(CorrectDZ4);
                                    Path path4 = Paths.get("HWFriday");
                                    try{
                                        Files.writeString(path4, CorrectDZ4, StandardCharsets.UTF_8);
                                    } catch (IOException ex){
                                        System.out.println("Invalid Path");
                                    }
                                }
                            }
                            sum++;
                        } while (a < 1 || a > 5);
                    } else {
                        System.out.println("Неправильное имя пользователя или пароль, попробуйте еще раз");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            } else {
                String a;
                sum = 0;
                do {
                    if (sum > 0) {
                        System.out.println("Введите имя пользователя:");
                    }
                    a = sc.nextLine();
                    sum++;
                } while (a.isEmpty());
                System.out.println("Введите пароль:");
                String c;
                sum = 0;
                do {
                    if (sum > 0) {
                        System.out.println("Введите пароль:");
                    }
                    c = sc.nextLine();
                    sum++;
                } while (c.isEmpty());
                Person person = new Person(a, c);
                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Registration"))) {
                    oos.writeObject(person);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Вы успешно зарегистрировались!");
            }
        } else if(pr.equals("Ученик") || pr.equals("ученик")){
            String b;
            System.out.println("Вы зарегистрированы?");
            System.out.println("Да или нет");
            int sum = 0;
            do {
                if (sum > 0) {
                    System.out.println("Вы зарегистрированы?");
                    System.out.println("Да или нет");
                }
                b = sc.nextLine();
                sum++;
            } while (!b.equals("Да") && !b.equals("да") && !b.equals("Нет") && !b.equals("нет"));
            System.out.println("Введите имя пользователя:");
            if (b.equals("Да") || b.equals("да")) {
                String q;
                sum = 0;
                do {
                    if (sum > 0) {
                        System.out.println("Введите имя пользователя:");
                    }
                    q = sc.nextLine();
                    sum++;
                } while (q.isEmpty());
                System.out.println("Введите пароль:");
                String w;
                sum = 0;
                do {
                    if (sum > 0) {
                        System.out.println("Введите пароль:");
                    }
                    w = sc.nextLine();
                    sum++;
                } while (w.isEmpty());
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("RegistrationStudent"))) {
                    Person person2 = new Person(q, w);
                    Person person = (Person) ois.readObject();
                    if (person.equals(person2)) {
                        System.out.println("Поздравляем, вы вошли в систему");
                        System.out.println("Какой день недели вам нужен? Введите число:");
                        System.out.println("1 - Понедельник");
                        System.out.println("2 - Вторник");
                        System.out.println("3 - Среда");
                        System.out.println("4 - Четверг");
                        System.out.println("5 - Пятница");
                        String onemore;
                        do {
                            int a = sc.nextInt();
                            if(a == 0){
                                break;
                            }
                            sum = 0;
                            do {
                                if (sum > 0) {
                                    System.out.println("Введите правильное число:");
                                    a = sc.nextInt();
                                }
                                switch (a) {
                                    case 1 -> {
                                        int check;
                                        do {
                                            System.out.println("1 - для просмотра расписания");
                                            System.out.println("2 - для просмотра дз");
                                            check = sc.nextInt();
                                            switch (check) {
                                                case 1:
                                                    DayOfWeeks monday = DayOfWeeks.Monday;
                                                    System.out.println(monday.getSubjects());
                                                    break;
                                                case 2:
                                                    try {
                                                        File file = new File("HWMonday");
                                                        Scanner scanner = new Scanner(file);
                                                        while (scanner.hasNextLine()) {
                                                            String data = scanner.nextLine();
                                                            System.out.println(data);
                                                        }
                                                        System.out.println();
                                                    } catch (IOException e){
                                                        System.out.println("Дз нет");
                                                    }
                                                    break;
                                            }
                                        } while(check < 1);
                                    }
                                    case 2 -> {
                                        int check1;
                                        do {
                                            System.out.println("1 - для просмотра расписания");
                                            System.out.println("2 - для просмотра дз");
                                            check1 = sc.nextInt();
                                            switch (check1) {
                                                case 1:
                                                    DayOfWeeks tuesday = DayOfWeeks.Tuesday;
                                                    System.out.println(tuesday.getSubjects());
                                                    break;
                                                case 2:
                                                    try {
                                                        File file1 = new File("HWTuesday");
                                                        Scanner scanner1 = new Scanner(file1);
                                                        while (scanner1.hasNextLine()) {
                                                            String data1 = scanner1.nextLine();
                                                            System.out.println(data1);
                                                        }
                                                        System.out.println();
                                                    } catch (IOException e){
                                                        System.out.println("Дз нет");
                                                    }
                                                    break;
                                            }
                                        } while(check1 < 1);
                                    }
                                    case 3 -> {
                                        int check2;
                                        do {
                                            System.out.println("1 - для просмотра расписания");
                                            System.out.println("2 - для просмотра дз");
                                            check2 = sc.nextInt();
                                            switch (check2) {
                                                case 1:
                                                    DayOfWeeks wednesday = DayOfWeeks.Wednesday;
                                                    System.out.println(wednesday.getSubjects());
                                                    break;
                                                case 2:
                                                    try {
                                                        File file2 = new File("HWWednesday");
                                                        Scanner scanner2 = new Scanner(file2);
                                                        while (scanner2.hasNextLine()) {
                                                            String data2 = scanner2.nextLine();
                                                            System.out.println(data2);
                                                        }
                                                        System.out.println();
                                                    } catch (IOException e){
                                                        System.out.println("Дз нет");
                                                    }
                                                    break;
                                            }
                                        } while(check2 < 1);
                                    }
                                    case 4 -> {
                                        int check3;
                                        do {
                                            System.out.println("1 - для просмотра расписания");
                                            System.out.println("2 - для просмотра дз");
                                            check3 = sc.nextInt();
                                            switch (check3) {
                                                case 1:
                                                    DayOfWeeks thursday = DayOfWeeks.Thursday;
                                                    System.out.println(thursday.getSubjects());
                                                    break;
                                                case 2:
                                                    try {
                                                        File file3 = new File("HWThursday");
                                                        Scanner scanner3 = new Scanner(file3);
                                                        while (scanner3.hasNextLine()) {
                                                            String data3 = scanner3.nextLine();
                                                            System.out.println(data3);
                                                        }
                                                        System.out.println();
                                                    } catch (IOException e){
                                                        System.out.println("Дз нет");
                                                    }
                                                    break;
                                            }
                                        } while(check3 < 1);
                                    }
                                    case 5 -> {
                                        int check4;
                                        do {
                                            System.out.println("1 - для просмотра расписания");
                                            System.out.println("2 - для просмотра дз");
                                            check4 = sc.nextInt();
                                            switch (check4) {
                                                case 1:
                                                    DayOfWeeks friday = DayOfWeeks.Friday;
                                                    System.out.println(friday.getSubjects());
                                                    break;
                                                case 2:
                                                    try {
                                                        File file4 = new File("HWFriday");
                                                        Scanner scanner4 = new Scanner(file4);
                                                        while (scanner4.hasNextLine()) {
                                                            String data4 = scanner4.nextLine();
                                                            System.out.println(data4);
                                                        }
                                                        System.out.println();
                                                    } catch (IOException e){
                                                        System.out.println("Дз нет");
                                                    }
                                                    break;
                                            }
                                        } while(check4 < 1);
                                    }
                                }
                                sum++;
                            } while (a < 1 || a > 5);
                            System.out.println("Хотите ли еще что-нибудь посмотреть?");
                            System.out.println("Если нет напишите 0");
                            System.out.println("Если да, то введите число от 1 до 5 для выбора дня недели");
                            onemore = sc.nextLine();
                        }while(onemore.isEmpty());
                    } else {
                        System.out.println("Неправильное имя пользователя или пароль, попробуйте еще раз");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            } else {
                String a;
                sum = 0;
                do {
                    if (sum > 0) {
                        System.out.println("Введите имя пользователя:");
                    }
                    a = sc.nextLine();
                    sum++;
                } while (a.isEmpty());
                System.out.println("Введите пароль:");
                String c;
                sum = 0;
                do {
                    if (sum > 0) {
                        System.out.println("Введите пароль:");
                    }
                    c = sc.nextLine();
                    sum++;
                } while (c.isEmpty());
                Person person = new Person(a, c);
                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("RegistrationStudent"))) {
                    oos.writeObject(person);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Вы успешно зарегистрировались!");
            }
        } else{
            System.out.println("Впишите учитель или ученик");
        }
    }
}