import java.io.Serializable;

public class Person implements Serializable {
    private transient int id;
    private  String username;
    private  String password;
    Person(String username, String password){
        this.username = username;
        this.password = password;
    }
    public boolean equals(Object obj){
        if(this == obj)
            return true;
        if(obj == null
                || this.getClass() != obj.getClass())
                return false;
        Person person = (Person)obj;
        return this.username.equals(person.username)
                && this.password.equals(person.password);
    }

}
