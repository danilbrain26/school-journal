public enum DayOfWeeks {
    Monday("ENG,RUS"),Tuesday("MATH"), Wednesday("RUS"), Thursday("KAZ"), Friday("AP");

    private String subjects;

    private String dz;

    DayOfWeeks(String subjects){
        this.subjects = subjects;
    }
    public String getSubjects(){
        return subjects;
    }

}
